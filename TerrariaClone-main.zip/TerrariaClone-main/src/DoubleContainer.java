public class DoubleContainer {
    public double[] doubles;
    public DoubleContainer(double[] doubles) {
        this.doubles = doubles;
    }
}
